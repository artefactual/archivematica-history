#!/bin/bash
java -jar /usr/local/OAIS/jhove/bin/JhoveView.jar -c /usr/local/OAIS/jhove/jhove.conf
